require("dotenv").config(); //set this for whole environment..this shoulb be first line of your file

const express = require("express");
const app = express();
app.use(express.json());
const port = 5000;

//const users = require("./users");

//mongoose 
const mongoose = require("mongoose");
const userModel = require("./models/user");

//const users = require("./model/user");

//connection string copied
mongoose
    .connect(process.env.MONGOURL)
    .then(() => console.log("mongo db connected"));

app.get("/", (req, res) => res.send("Hello Fullstack!"));


//Database CRUD Operation
//-------------------------------Get list of all users
app.get("/list",async (req,res) => {
  //find all collection from userModel
  const userList = await userModel.find({},{username: true}); //first parameter(Query parameter) empty:-what we r looking for, second:- what we need for ex.=username

  if(userList.length == 0)
  {
    return res.json({data: "no users in fullstack"});
  }

  return res.json({data: userList});
});
/*
  URL:- http://localhost:5000/list

*/


//-----------------------register user 
//(smj ni aaya code) we didn't async nd await bcz we r not waiting for any response from DB
app.post("/registration",(req,res) => {
  const { newUser } = req.body; //key newUser
  userModel.create(newUser);

  return res.json({data: "Registered successfully..."});
});
/*POSTMAN
  {

  }
*/


//-----------------------------------------login user
app.post("/login",async (req,res) => {
  const uname = req.body.username;
  const pass = req.body.password;

  const user = await userModel.findOne({username: uname,password: pass}); //query where username is eqal to uname nd same as in pass

  if(user)
  {
    return res.json({data: "Login Successfully"});
  }

  return res.json({data: "Wrong credintials."});

});
/*POSTMAN
  {
    "username": "Hetvi",
    "password": "hetvi"
  }
*/


//--------------------------------------------Update User
//:uname capture kre ke aanu change krvanu che
app.put("/user/changepassword/:uname",async (req,res) => {
  const uname = req.params.uname; //pass it in URL
  const pass = req.body.password; //pass it in body(sensitive)

  const updatedUser = await userModel.findOneAndUpdate(
    { username: uname },
    { password: pass },
    { new: true }
  );  //PARAMATERS 1st:- query,2nd:- pass update,3rd:- new copy(update)

    return res.json({data: "password updated successfully..."});

});
/*POSTMAN
  http://localhost:5000/user/changepassword/Hetvi

  {
      "password": "hetu"
  }

*/


//------------------------------------------Delete User
//(async and await u can use here to check uname is there or not)
app.delete("/user/deleteuser/:uname",async (req,res) => {
  
  const uname = req.params.uname;
  const deletedUser = await userModel.findOneAndDelete({username:uname});

  return res.json({data: "user deleted successfully"});
});
/*POSTMAN
  http://localhost:5000/user/deleteuser/Hetvi

*/


app.listen(port, () => console.log(`server running on port 5000`));


//----------LOGICAL OPERATOR----------------
//$inc - increment value
//$min - find minimum
//$max - maximum
//$set - set data
//$unset - remove a property from an object

//-------------ARRAY OPERATORS---------
//$push
//$pop
//$pull
//$addToSet




/*require("dotenv").config();

const express = require("express");
const app = express();
app.use(express.json());
const port = 5000;
const mongoose = require("mongoose");

const users = require("./users");

mongoose
  .connect(process.env.MONGOURL)
  .then(() => console.log("mongo db connected"));

app.get("/", (req, res) => res.send("Hello World!"));

app.listen(port, () => console.log(`server running on port 5000`));*/

/*
app.post("/registration", (req, res) => {
    const uname = req.body.username;
    const pass = req.body.password;
    const name = req.body.name;
    const age = req.body.age;
    const user = users.filter((u) => u.username === uname);
  
    if (user.length === 0) {
      return res.json({ data: "registration successfull" });
    } else {
      return res.json({ data: "username already taken. Please choose another" });
    }
  });



app.post("/login", (req, res) => {
  const uname = req.body.username;
  const pass = req.body.password;
  const user = users.filter((u) => u.username === uname && u.password === pass);

  if (user.length === 0) {
    return res.json({ data: "wrong credentials! please try again." });
  } else {
    return res.json({ data: "login successfull" });
  }
});

// http://localhost:5000/list/?name=josh&age=25
app.get("/list", (req, res) => {
  const name = req.query.name;
  const age = req.query.age;

  let userList = users.filter((u) => u.name === name && u.age > parseInt(age));

  if (userList.length === 0) {
    return res.json({ data: "user not found" });
  } else {
    return res.json({ data: userList });
  }
});
*/
