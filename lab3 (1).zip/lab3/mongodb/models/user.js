const mongoose = require("mongoose");

//it will stop mongoose doing lowercase nd also stop plurizing
//mongoose.pluralize(null);

//create schema name with userSchema
//specify keys nd its datatype uh want
const userSchema = mongoose.Schema({
    username: String,
    password: String,
    name: String,
    age: Number,
});

//first parameter collection name,2nd is schema
const userModel = mongoose.model("fullstack",userSchema,"fullstack");

//use it in another file
module.exports=userModel;

